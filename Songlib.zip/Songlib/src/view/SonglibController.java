package view;

import java.util.ArrayList;
import java.io.File;
import java.util.Scanner;
import java.util.StringTokenizer;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.ListView;
import javafx.scene.text.Text;
import javafx.stage.Stage;

public class SonglibController {

	// widgets from fxml for delete/edit section 
	@FXML   private Text title1;
	@FXML   private Text artist1;
	@FXML   private Text album1;
	@FXML   private Text year1;
	
	// widgets from fxml for delete/edit section 
	@FXML	private Text title2;
	@FXML	private Text artist2;
	@FXML	private Text album2;
	@FXML	private Text year2;
	
	// widget from fxml for listView
	@FXML	private ListView<String> listView;
	
	//stores all Songs in list
	private ArrayList<Song> song = new ArrayList<Song>();

	private ObservableList<String> obsList;     
		
		
		//private class to store Songs as objects. Useful to get attributes. Also will be used to update songs.txt after updates are made
		private class Song{
			private String song_string; // song_string is what gets displayed on listView, rest are self-explanatory
			private String song_name;
			private String song_artist;
			private String song_album;
			private String song_year;
		
			public String getString() {
				return this.song_string;
			}
			public String getName() {
				return this.song_name;
			}
			public String getArtist() {
				return this.song_artist;
			}
			public String getAlbum() {
				return this.song_album;
			}
			public String getYear() {
				return this.song_year;
			}

		}

	public void start(Stage mainStage) {                
		// initialize obslist to an empty ObservableList, allows us to set/get items  
		obsList = FXCollections.observableArrayList();   
		try {
			File file = new File("src/app/songs.txt");  //stores songs so that they persist after we 
			Scanner s = new Scanner(file);
			while(s.hasNextLine()) {
				String k = s.nextLine();
				//we are separating attributes of songs by |, so tokenize the line by that
				StringTokenizer st = new StringTokenizer(k, "|");
				Song temp = new Song();
				
				//NOTE: in order for this to work we will need to have a space in between |'s in the songs.txt
				// aka a song with no year would look like this: song_title|song_artist|song_year| |
				//without the final space it won't work (could change this but its an easy solution so �\_(._.)_/� )
				temp.song_name= st.nextToken();
				System.out.println(temp.getName());
				temp.song_artist= st.nextToken();
				System.out.println(temp.getArtist());
				temp.song_album = st.nextToken();
				System.out.println(temp.getAlbum());
				temp.song_year = st.nextToken();
				System.out.println(temp.getYear());
				temp.song_string = temp.getName()+"|"+temp.getArtist();
				System.out.println(temp.getString());
				song.add(temp);
				obsList.add(temp.song_string);
			}
			s.close();
		}catch (Exception e) {
			System.out.println("ERROR");
		}
		System.out.println(obsList);
		
		// if songs.txt contains any songs, we will have auto-selected the first song and we should update the Text fields to reflect that
		if(song.size() > 0) {
			title1.setText("Title: "+ song.get(0).song_name);
			artist1.setText("Artist: "+ song.get(0).song_artist);
			album1.setText("Album: "  + song.get(0).song_album);
			year1.setText("Year: "+ song.get(0).song_year);
		}
		
		listView.setItems(obsList); 
		
		// select the first item
		listView.getSelectionModel().select(0);

		// set listener for the items
		listView
		.getSelectionModel()
		.selectedIndexProperty()
		.addListener(
				(obs, oldVal, newVal) -> 
				showItemInputDialog(mainStage));
		

	}
	
	
	private void showItemInputDialog(Stage mainStage) {                
		String item = listView.getSelectionModel().getSelectedItem();
		
		//find the song that is selected and get its attributes
		for(int i = 0; i < song.size(); i++) {
			Song temp = song.get(i);
			if(temp.song_string.equals(item)) {
				title1.setText("Title: "+ temp.song_name);
				artist1.setText("Artist: "+ temp.song_artist);
				album1.setText("Album: "  + temp.song_album);
				year1.setText("Year: "+ temp.song_year);
			}
		}
	}
	
	public void delete(ActionEvent e) {  // name of method = name assigned in # directive in fxml for onAction attribute
		int index = listView.getSelectionModel().getSelectedIndex();
		
		
		if(index != -1) { //index is -1 if nothing is selected
			
			listView.getItems().remove(index); //deletes selected song
			
			//we always have a song selected(if one exists) so update the Text fields to reflect that selected song
			String item = listView.getSelectionModel().getSelectedItem();
			for(int i = 0; i < song.size(); i++) {
				Song temp = song.get(i);
				if(temp.song_string.equals(item)) {
					title1.setText("Title: "+ temp.song_name);
					artist1.setText("Artist: "+ temp.song_artist);
					album1.setText("Album: "  + temp.song_album);
					year1.setText("Year: "+ temp.song_year);
				}
			}
			//update Song[] song and update the songs.txt file
			song.remove(index);
			updateSongList();
		}
		
	}
	
	
	// still needs to be implemented
	// will loop through the Song[] and write to the file songs.txt so that any changes are saved
	public void updateSongList() {
		
	}

}
