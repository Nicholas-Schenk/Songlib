/*
 * Authors: Nicholas Schenk, Bryan Smith
*/
package view;

import java.util.ArrayList;
import java.util.Optional;
import java.io.File;
import java.util.Scanner;
import java.util.StringTokenizer;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.ListView;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.ButtonType;
import javafx.scene.text.Text;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class SonglibController {

	// widgets from fxml for edit section 
	@FXML   private TextField edit_title;
	@FXML   private TextField edit_artist;
	@FXML   private TextField edit_album;
	@FXML   private TextField edit_year;
	
	//widgets from fxml for delete section 
	@FXML	private Text title2;
	@FXML	private Text artist2;
	@FXML	private Text album2;
	@FXML	private Text year2;
	
	//using textfield for add section
	@FXML private TextField add_title;
	@FXML private TextField add_artist;
	@FXML private TextField add_album;
	@FXML private TextField add_year;
	
	// widget from fxml for listView
	@FXML	private ListView<String> listView;
	
	//stores all Songs in list
	private ArrayList<Song> song = new ArrayList<Song>();

	private ObservableList<String> obsList;     
		
		
		//private class to store Songs as objects. Useful to get attributes. Also will be used to update songs.txt after updates are made
		public class Song{
			private String song_string; // song_string is what gets displayed on listView, rest are self-explanatory
			private String song_name;
			private String song_artist;
			private String song_album;
			private String song_year;
		
			public String getString() {
				return this.song_string;
			}
			public String getName() {
				return this.song_name;
			}
			public String getArtist() {
				return this.song_artist;
			}
			public String getAlbum() {
				return this.song_album;
			}
			public String getYear() {
				return this.song_year;
			}
			@Override
			public String toString() {
				return this.song_name+"|"+this.song_artist+"|"+this.song_album+" |"+this.song_year+" |";
			}

		}

	public void start(Stage mainStage) {                
		// initialize obslist to an empty ObservableList, allows us to set/get items  
		obsList = FXCollections.observableArrayList();   
		try {
			File file = new File("src/app/songs.txt");  //stores songs so that they persist after we 
			Scanner s = new Scanner(file);
			while(s.hasNextLine()) {
				String k = s.nextLine();
				//we are separating attributes of songs by |, so tokenize the line by that
				StringTokenizer st = new StringTokenizer(k, "|");
				Song temp = new Song();
				
				//NOTE: in order for this to work we will need to have a space in between |'s in the songs.txt
				// aka a song with no year would look like this: song_title|song_artist|song_year| |
				//without the final space it won't work (could change this but its an easy solution so �\_(._.)_/� )
				temp.song_name= st.nextToken();
				temp.song_artist= st.nextToken();
				temp.song_album = st.nextToken().trim();
				temp.song_year = st.nextToken().trim();
				temp.song_string = temp.getName()+"|"+temp.getArtist();
				song.add(temp);
				obsList.add(temp.song_string);
			}
			s.close();
		}catch (Exception e) {
			System.out.println("ERROR");
		}
		
		// if songs.txt contains any songs, we will have auto-selected the first song and we should update the Text fields to reflect that
		if(song.size() > 0) {
			title2.setText("Title: "+song.get(0).song_name);
			artist2.setText("Artist: "+song.get(0).song_artist);
			album2.setText("Album: "+song.get(0).song_album);
			year2.setText("Year: "+song.get(0).song_year);
			
			edit_title.setText(song.get(0).song_name);
			edit_artist.setText(song.get(0).song_artist);
			edit_album.setText(song.get(0).song_album);
			edit_year.setText(song.get(0).song_year);
		}
		
		listView.setItems(obsList); 
		
		// select the first item
		listView.getSelectionModel().select(0);

		// set listener for the items
		listView
		.getSelectionModel()
		.selectedIndexProperty()
		.addListener(
				(obs, oldVal, newVal) -> 
				showItemInputDialog(mainStage));
	}
	
	
	private void showItemInputDialog(Stage mainStage) {                
		String item = listView.getSelectionModel().getSelectedItem();
		
		//find the song that is selected and get its attributes
		for(int i = 0; i < song.size(); i++) {
			Song temp = song.get(i);
			if(temp.song_string.equals(item)) {
				title2.setText("Title: "+ temp.song_name);
				artist2.setText("Artist: "+temp.song_artist);
				album2.setText("Album: "+temp.song_album);
				year2.setText("Year: "+temp.song_year);
				
				edit_title.setText(temp.song_name);
				edit_artist.setText(temp.song_artist);
				edit_album.setText(temp.song_album);
				edit_year.setText(temp.song_year);
			}
		}
	}
	
	public void delete(ActionEvent e) {  // name of method = name assigned in # directive in fxml for onAction attribute
		int index = listView.getSelectionModel().getSelectedIndex();
		
		
		if(index != -1) { //index is -1 if nothing is selected
			
			
			Alert alert = new Alert(AlertType.CONFIRMATION);
			alert.setTitle("Confirmation Dialog");
			alert.setHeaderText("Delete this song?");

			Optional<ButtonType> result = alert.showAndWait();
			if (result.get() == ButtonType.OK){
				listView.getItems().remove(index); //deletes selected song
				
				//we always have a song selected(if one exists) so update the Text fields to reflect that selected song
				String item = listView.getSelectionModel().getSelectedItem();
				for(int i = 0; i < song.size(); i++) {
					Song temp = song.get(i);
					if(temp.song_string.equals(item)) {
						
						title2.setText("Title: "+ temp.song_name);
						artist2.setText("Artist: "+temp.song_artist);
						album2.setText("Album: "+temp.song_album);
						year2.setText("Year: "+temp.song_year);
						
						edit_title.setText(temp.song_name);
						edit_artist.setText(temp.song_artist);
						edit_album.setText(temp.song_album);
						edit_year.setText(temp.song_year);
					}
				}
				//update Song[] song and update the songs.txt file
				song.remove(index);
		
			} 
		}
		
	}
	public ArrayList<Song> getSongs(){
		return song;
	}
	
	public void add(ActionEvent e) {
		//get values user inputs
		String new_title = add_title.getText().trim();
		String new_artist = add_artist.getText().trim();
		String new_album = add_album.getText().trim();
		String new_year = add_year.getText().trim();
		
		boolean year_valid = true;
		
		//check if there is an artist and song name
		if ((new_title != null && !new_title.isEmpty()) 
				&& (new_artist != null && !new_artist.isEmpty())) {
			
			//check if the song to add is a duplicate
			Boolean isDuplicate = false;
			int pos = -1;
			for(int i = 0; i < song.size(); i++) {
				Song temp = song.get(i);
				//System.out.println(temp.getName());
				//System.out.println(temp.getArtist());
				System.out.println(new_title.compareToIgnoreCase(temp.getName()));
				if(new_title.compareToIgnoreCase(temp.getName())>0) {
					continue;
				}else if(new_title.compareToIgnoreCase(temp.getName())<0) {
					pos = i;
					break;
				}else {
					if(new_artist.compareToIgnoreCase(temp.getArtist())<0) {
						pos = i;
						break;
					}else if(new_artist.compareToIgnoreCase(temp.getArtist())>0) {
						continue;
					}else {
						isDuplicate = true;
						break;
					}
				}
				
			}
			if(pos == -1) {
				pos = song.size();
			}
			System.out.println("POS:"+pos);
			
			if(!isDuplicate) { //add new song, select it
				Song newSong = new Song();
			
				newSong.song_name= new_title;
				newSong.song_artist= new_artist;
				if (new_album == null || new_album.isEmpty()) {
					newSong.song_album = "";
				}else {
					newSong.song_album = new_album;
				}
				if (new_year == null || new_year.isEmpty()) {
					newSong.song_year = "";
				}else {
					try {
						int year = Integer.parseInt(new_year);
						if (year > 0) {
							newSong.song_year = new_year;
						}else {
							year_valid = false;
							Alert alert = new Alert(AlertType.INFORMATION);
							alert.setTitle("Year error");
							alert.setHeaderText("Year must be an integer greater than 0, or leave the field empty");
							alert.showAndWait();
						}
					} 
					catch (NumberFormatException nfe){
						year_valid = false;
						Alert alert = new Alert(AlertType.INFORMATION);
						alert.setTitle("Year error");
						alert.setHeaderText("Year must be an integer greater than 0, or leave the field empty");
						alert.showAndWait();
						}
						
				}
					
				newSong.song_string = newSong.getName()+"|"+newSong.getArtist();
				if (year_valid) {
					
				
					
					Alert alert = new Alert(AlertType.CONFIRMATION);
					alert.setTitle("Confirmation Dialog");
					alert.setHeaderText("Add this song?");
	
					Optional<ButtonType> result = alert.showAndWait();
					if (result.get() == ButtonType.OK){
					    // ... user chose OK
						song.add(pos, newSong);
						obsList.add(pos, newSong.song_string);
						int newSongIndex = song.indexOf(newSong);
						listView.getSelectionModel().select(newSongIndex);
					} 
				}
				
			}else { //show dialog box if song is a duplicate
				Alert alert = new Alert(AlertType.INFORMATION);
				alert.setTitle("Duplicate addition");
				alert.setHeaderText("You may not add a song that already exists");
				alert.showAndWait();
			}
			
		}else {
			Alert alert = new Alert(AlertType.INFORMATION);
			alert.setTitle("No values");
			alert.setHeaderText("You need a song title and artist to add a song");
			alert.showAndWait();

		}
		
		
	}
	public void edit(ActionEvent e) {
		int index = listView.getSelectionModel().getSelectedIndex();
		//nothing was changed if this if evaluates to false
		if(index != -1  &&  (edit_title.getText().trim() != null && !edit_title.getText().trim().isEmpty()) && (edit_artist.getText().trim() != null && !edit_artist.getText().trim().isEmpty())) { //index is -1 if nothing is selected
			boolean isDuplicate = false;
			boolean year_valid = true;
			String new_item = edit_title.getText().trim() +"|"+edit_artist.getText().trim();
			for(int i = 0; i< song.size();i++) {
				Song temp = song.get(i);
				if(temp.song_string.equals(new_item)) {
					if (index != i) {
						isDuplicate=true; //can't change to be duplicate
						Alert alert = new Alert(AlertType.INFORMATION);
						alert.setTitle("Duplicate error");
						alert.setHeaderText("You may not edit a song into one that already exists");
						alert.showAndWait();

						break;
					}else {
						if(temp.song_album.equals(edit_album.getText().trim()) && temp.song_year.equals(edit_year.getText().trim())) {
							isDuplicate=true;
							Alert alert = new Alert(AlertType.INFORMATION);
							alert.setTitle("Error");
							alert.setHeaderText("You need to change at least one feild to edit");
							alert.showAndWait();
							break;
						}
					}
				}
			}
			
			if(!isDuplicate) {
				
				//update selected song
				title2.setText("Title: "+ edit_title.getText().trim());
				artist2.setText("Artist: "+edit_artist.getText().trim());
				album2.setText("Album: "+edit_album.getText().trim());
				year2.setText("Year: "+edit_year.getText().trim());
				
				
				//make new song that we will add to the song list
				Song temp2 = new Song();
				temp2.song_name = edit_title.getText().trim();
				temp2.song_artist = edit_artist.getText().trim();
				temp2.song_string = temp2.song_name+"|"+temp2.song_artist;
				if (edit_album.getText().trim() == null || edit_album.getText().trim().isEmpty()) {
					temp2.song_album = "";
				}else {
					temp2.song_album = edit_album.getText().trim();
				}
				if (edit_year.getText().trim() == null || edit_year.getText().trim().isEmpty()) {
					temp2.song_year = "";
				}else {
					try {
						int year = Integer.parseInt(edit_year.getText().trim());
						if (year > 0) {
							temp2.song_year = edit_year.getText().trim();
						}else {
							year_valid = false;
							Alert alert = new Alert(AlertType.INFORMATION);
							alert.setTitle("Year error");
							alert.setHeaderText("Year must be an integer greater than 0, or leave the field empty");
							alert.showAndWait();
						}
					} 
					catch (NumberFormatException nfe){
						year_valid = false;
						Alert alert = new Alert(AlertType.INFORMATION);
						alert.setTitle("Year error");
						alert.setHeaderText("Year must be an integer greater than 0, or leave the field empty");
						alert.showAndWait();
						}
						
				}
				
				//find alphabetical position of new song
				int pos = song.size();
				for(int i = 0; i < song.size(); i++) {
					Song temp = song.get(i);
					if(i == index) {
						continue;
					}
					if(edit_title.getText().trim().compareToIgnoreCase(temp.getName())>0) {
						continue;
					}else if(edit_title.getText().trim().compareToIgnoreCase(temp.getName())<0) {
						pos = i;
						break;
					}else {
						if(edit_artist.getText().trim().compareToIgnoreCase(temp.getArtist())<0) {
							pos = i;
							break;
						}else if(edit_artist.getText().trim().compareToIgnoreCase(temp.getArtist())>0) {
							continue;
						}else {
							System.out.println("MAJOR ERROR HAPPENED"); //means that new song was a duplicate even tho we previously made sure that was impossible
							break;
						}
					}
				}
				if(year_valid) {
					
					Alert alert = new Alert(AlertType.CONFIRMATION);
					alert.setTitle("Confirmation Dialog");
					alert.setHeaderText("Make this edit?");
	
					Optional<ButtonType> result = alert.showAndWait();
					if (result.get() == ButtonType.OK){
					    // ... user chose OK
						//Add in updated song
						//update ListView
						obsList.add(pos, edit_title.getText().trim()+"|"+edit_artist.getText().trim());
					
						//add new song to Song list
						song.add(pos, temp2);
						
						//select the song
						listView.getSelectionModel().select(pos);
						
						//where the song we need to remove changes if the updated song comes before the original 		
						if(pos < index) {
							index++;
						}
						listView.getItems().remove(index);
						song.remove(index);
					}
				}
			}
		}
	}
}
