package app;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javafx.application.Application;
//import javafx.event.EventHandler;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
//import javafx.stage.WindowEvent;
import view.SonglibController;
import view.SonglibController.Song;

public class SonglibApp extends Application {

	@Override
	public void start(Stage primaryStage) throws Exception {
		FXMLLoader loader = new FXMLLoader();   
		loader.setLocation(
				getClass().getResource("/view/songlib.fxml"));
		AnchorPane root = (AnchorPane)loader.load();

		SonglibController songlibController = 
				loader.getController();
		songlibController.start(primaryStage);

		Scene scene = new Scene(root, 400, 600);
		primaryStage.setScene(scene);
		primaryStage.setOnCloseRequest(event -> {
			ArrayList<Song> updated_song_list = songlibController.getSongs();
			
			try{
				PrintWriter p = new PrintWriter("src/app/songs.txt");
				for(int i = 0; i < updated_song_list.size();i++) {
					p.print(updated_song_list.get(i).toString());
					p.print("\n");
				}
				p.close();
			}catch(IOException e) {
				System.out.println(e);
			}
		});
		
		
		primaryStage.show();

	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		launch(args);
		//System.out.println("when does this print?");
		

	}

}
